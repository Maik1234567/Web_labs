import ProductCard from '../../components/ProductCard/ProductCard';
import FilledButton from '../../components/Buttons/FilledButton';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Spinner from '../../components/Spinner/Spinner';

const CatalogPreview = () => {
    const [viewMoreStep, setViewMoreStep] = useState(0);
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        axios.get(`http://localhost:3001/banks`)
            .then(res => res.data)
            .then(data => {
                setProducts(data);
                setIsLoading(false);
            })
            .catch(() => {})
    }, []);

    return isLoading ? <Spinner /> : <>
        <div className="flex justify-center pb-4">
            <div className='grid grid-cols-4 gap-4'>
                {
                    products.slice(0, (viewMoreStep + 1) * 4).map((el, idx) => {
                        return <ProductCard key={idx} title={el.bankName} productPageHref={`/catalog/${el.id - 1}`}/>
                    })
                }
                {
                    (viewMoreStep + 1) * 4 > products.length ?
                    <ProductCard key={-1}
                    title="See More"
                    desc="Click the card and see more unique artists or buy a ticket for a show of your life!"
                    withoutCard={true}
                    productPageHref="/catalog"
                    className="text-white bg-green-500 hover:bg-green-600" />
                    : null
                }
            </div>
        </div>
        {
            products.length > (viewMoreStep + 1) * 4 ?
            <div className="flex justify-center">
                <FilledButton name="View More" className="mx-auto"
                onClick={() => {
                    setViewMoreStep(viewMoreStep + 1)
                }}/>
            </div>
            :
            null
        }
    </>
}

export default CatalogPreview;
