import { createBrowserRouter } from 'react-router-dom';
import MainLayout from '../../lab8/src/layouts/MainLayout';
import HomePage from '../../lab8/src/pages/Home';
import Catalog from './pages/Catalog';
import ProductPage from './pages/Product';
import axios from 'axios';
import CartPage from './pages/Cart';

export const router = createBrowserRouter([
    {
        path: '/',
        element: <MainLayout>
            <HomePage />
        </MainLayout>,
    },
    {
        path: '/catalog',
        element: <MainLayout>
            <Catalog />
        </MainLayout>,
    },
    {
        path: '/catalog/:id',
        element: <MainLayout>
            <ProductPage />
        </MainLayout>,
        loader: ({ params }) => {
            const { id } = params;
            const product = axios.get(`http://localhost:3001/banks/${parseInt(id) + 1}`).then(res => res.data)
            return product;
        },
        errorElement: <p>error</p>
    },
    {
        path: '/cart',
        element: <MainLayout>
            <CartPage />
        </MainLayout>
    }
]);
