const Logo = () => {
    return <p className="font-bold">Banks</p>
}

export default Logo;
