import { useDispatch } from "react-redux";
import FilledButton from "../Buttons/FilledButton";
import { addItem } from "../../features/cart/cartSlice";

const SingleProductPage = ({ product }) => {
    const { bankName, users, credits, description } = product;
    const dispatch = useDispatch();

    return <div className='flex justify-evenly mb-[200px]'>
        <div>
            <h1 className='font-bold text-3xl mb-2'>{bankName}</h1>
            <div className='flex gap-2'>
                <div className='text-sm border rounded-[6px] px-2 py-1 w-fit'>
                    {`Month Listeners: ${users}`}
                </div>
                <div className='text-sm border rounded-[6px] px-2 py-1 w-fit'>
                    {`Total credits: ${credits}`}
                </div>
            </div>
            <p>{description}</p>
            <FilledButton name="Add to cart" onClick={() => {
                dispatch(addItem({
                    name: `${bankName}`,
                    quantity: 1,
                    credits: credits,
                }));
                alert(`You have added ${bankName}`)
            }} />
        </div>
    </div>
}

export default SingleProductPage;
