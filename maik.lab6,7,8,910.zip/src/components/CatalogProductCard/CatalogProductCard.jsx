import FilledButton from "../Buttons/FilledButton";

const CatalogProductCard = ({ item }) => {
    const { bankName, users, credits, id } = item;

    return <div className="border rounded-[8px] p-4 max-w-[350px] transition-all hover:shadow-xl ">
        <p className="font-semibold">{bankName}</p>
        <p className="mb-2">{`Total users: ${users}`}</p>
        <p className="font-semibold">{`Total credits in UAH: ${credits}`}</p>
        <FilledButton name="View More" className="w-full" href={`/catalog/${id - 1}`} />
    </div>
}

export default CatalogProductCard;
