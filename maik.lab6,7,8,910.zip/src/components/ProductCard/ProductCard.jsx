import { Link } from 'react-router-dom';

const ProductCard = ({title, desc, img, productPageHref, className, withoutCard = false}) => {
    return <Link to={productPageHref}>
        <div className={`border rounded-[8px] p-4 max-w-[200px] h-full ${className}`}>
            <p className="font-semibold">{title}</p>
        </div>
    </Link>
}

export default ProductCard;
