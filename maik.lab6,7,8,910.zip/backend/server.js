import express from 'express'
import cors from 'cors'
import { db } from './db.js'

const app = express();

app.use(express.json())
app.use(cors())

const sortList = ({ filterBy, filterOrder, search }) => {
    let sortedList = [...db];

    if (filterOrder) {
        if (filterOrder === 'toLower') {
            sortedList.sort((a, b) => b[filterBy] - a[filterBy])
        }
        else if (filterOrder === 'toHigher') {
            sortedList.sort((a, b) => a[filterBy] - b[filterBy])
        }
    }

    if (search) {
        sortedList = sortedList.filter((el) => el.bankName.toLowerCase().includes(search.toLowerCase()))
    }

    return sortedList
}

app.get('/banks', (req, res) => {
    const { filterBy, filterOrder, search } = req.query;
    res.json(sortList({filterBy, filterOrder, search}))
});

app.get('/banks/:bank_id', (req, res) => {
    const { bank_id } = req.params;
    console.log(bank_id)
    res.json( db[parseInt(bank_id) - 1] )
})

app.listen(3001, () => {
    console.log('Server was started!')
});
